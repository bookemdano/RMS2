Can be run commandline
Old Style
Kanga.exe RTS
New STyle
Kanga.exe Omnitracs RA
Kanga.exe SDLC RTS RTS-3.6.9

Will only return up to 1000 results